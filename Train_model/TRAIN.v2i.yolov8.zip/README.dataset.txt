# TRAIN > 2024-04-14 10:15am
https://universe.roboflow.com/phanmanh2005hcgmailcom/train-kanxp

Provided by a Roboflow user
License: CC BY 4.0

